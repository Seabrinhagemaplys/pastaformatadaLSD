## Visão Geral
Esse bloco serve para caclular um OR para duas entradas. 

### Link do EDA playground

[link do projeto](https://edaplayground.com/x/LR69)

