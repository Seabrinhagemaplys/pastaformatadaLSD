## Visão geral
Essa pasta contém todas as estruturas de blocos lógicos presentes no projeto, além de seus testbenches e arquivos de leitura que os contextualizam.
