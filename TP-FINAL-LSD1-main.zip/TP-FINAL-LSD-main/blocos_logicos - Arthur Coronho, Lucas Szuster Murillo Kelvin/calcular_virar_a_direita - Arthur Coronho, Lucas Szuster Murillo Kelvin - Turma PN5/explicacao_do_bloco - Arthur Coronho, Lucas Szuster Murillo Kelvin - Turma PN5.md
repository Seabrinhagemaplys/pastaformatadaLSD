## Visão Geral

No modelo de semáforo, há uma saída especial que indica se um carro pode ou não virar para a direita, mesmo quando o sinal está vermelho. 
Para permitir isto, é necessário um bloco que seja capaz de avaliar as entradas relativas a pedestres (entradas que indicam se há ou não um pedestre atravessando) e emergências (em ambas as vias) para calcular se um carro pode ou não passar.
Esta é a função deste bloco.

### Link do projeto no EDA playground

[link do projeto](https://edaplayground.com/x/Hpj_)
