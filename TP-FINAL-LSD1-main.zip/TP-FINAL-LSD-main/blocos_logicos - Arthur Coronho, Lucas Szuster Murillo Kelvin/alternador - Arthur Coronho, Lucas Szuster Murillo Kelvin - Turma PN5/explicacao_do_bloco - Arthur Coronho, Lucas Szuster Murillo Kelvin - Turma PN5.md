## Visão Geral

No modelo do semáforo, há um estado no qual o sinal fica em stand - by, no modo noturno, em que a luz amarela fica "piscando". Para isso 
implementamos um alternador, que faz as saídas alternarem entre 0 e 1 quando habilitado, resultando no efeito esperado.

#### Link projeto no EDA playground

[link do projeto](https://edaplayground.com/x/mKHt)
