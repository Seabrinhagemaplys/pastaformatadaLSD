## Visão Geral

Esse bloco armazena as informações de entrada para N bits e, na próxima borda de subida do clock as exibe em sua saída.

### Link do projeto no EDA playground

[link do projeto](https://edaplayground.com/x/c5fL)
